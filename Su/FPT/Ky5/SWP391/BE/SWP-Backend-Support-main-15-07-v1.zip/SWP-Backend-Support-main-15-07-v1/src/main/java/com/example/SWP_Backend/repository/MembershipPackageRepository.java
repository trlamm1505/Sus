package com.example.SWP_Backend.repository;

import com.example.SWP_Backend.entity.MembershipPackage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MembershipPackageRepository extends JpaRepository<MembershipPackage, Long> {
}
